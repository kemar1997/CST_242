﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project11_CST242
{
    class BooksClass
    {
        /// <summary>
        /// The connection string to the Microsoft Access "Books.mdb" database.
        /// </summary>
        public static String booksConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|Books.mdb;User Id=admin;Password=;";
    }
}
